package com.example.pokedox.model;

public class AbilityInfo {
    public String name;
}
