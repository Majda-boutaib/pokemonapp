package com.example.pokedox.service;

import com.example.pokedox.model.PokemonResponse;
import com.example.pokedox.model.PokemonsInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PokemonsRepoService {
    @GET("pokemon")
    public Call<PokemonResponse> searchPokemons();

    @GET("pokemon/{name}")
    Call<PokemonsInfo> searchPokemonDetails(@Path("name") String name);
}
