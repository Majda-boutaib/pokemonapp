package com.example.pokedox.model;

import java.util.List;

public class PokemonsInfo {
    public int height;
    public int weight;
    public List<Ability> abilities;
}

