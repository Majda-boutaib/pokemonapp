package com.example.pokedox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.example.pokedox.model.PokemonResponse;
import com.example.pokedox.model.Pokemons;
import com.example.pokedox.model.PokemonsListViewModel;
import com.example.pokedox.service.PokemonsRepoService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    List<Pokemons> data =new ArrayList<>();
    public static final String POKEMON_NAME_PARAM="pokemons.name";
    public static final String POKEMON_IMAGE_PARAM="PokemonsListViewModel.imageViewPokemon" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //EditText editTextQuery = findViewById(R.id.editTextQuery);
        Button buttonSearch = findViewById(R.id.buttonSearch);
        ListView listviewpokemons =findViewById(R.id.listviewpokemons);

        //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,data);
        PokemonsListViewModel listViewModel=new PokemonsListViewModel(this,R.layout.pokemons_list_view_layout,data);
        listviewpokemons.setAdapter(listViewModel);
        Retrofit retrofit =new Retrofit.Builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

 //       buttonSearch.setOnClickListener(new View.OnClickListener() {
  //          @Override
    //        public void onClick(View view) {
                //String query =editTextQuery.getText().toString();
                PokemonsRepoService pokemonsRepoService =retrofit.create(PokemonsRepoService.class);
                Call<PokemonResponse> callPokemon =pokemonsRepoService.searchPokemons();
                callPokemon.enqueue(new Callback<PokemonResponse>() {
                    @Override
                    public void onResponse(Call<PokemonResponse> call, Response<PokemonResponse> response) {
                        Log.i("info", call.request().url().toString());
                        if(!response.isSuccessful()){
                            Log.i("info",String.valueOf(response.code()));
                            return;
                        }
                        PokemonResponse pokemonResponse = response.body();
                        for (Pokemons pokemons:pokemonResponse.results){
                            data.add(pokemons);
                        }
                        listViewModel.notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(Call<PokemonResponse> call, Throwable t) {
                        Log.e("error","Error");

                    }
                });

       //     }
     //   });

        listviewpokemons.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String name=data. get(position).name;
                Log.i("info",name);
                Intent intent= new Intent(getApplicationContext(),InfoActivity.class);

                String imageUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/" + (position+1) + ".png";
                intent.putExtra(POKEMON_NAME_PARAM,name);
                intent.putExtra(POKEMON_IMAGE_PARAM, imageUrl);

                startActivity(intent);

            }
        });
    }
}