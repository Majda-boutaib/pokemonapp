package com.example.pokedox.model;

public class Ability {
    public AbilityInfo ability;
}
