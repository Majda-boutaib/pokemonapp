package com.example.pokedox;

import static com.example.pokedox.MainActivity.POKEMON_IMAGE_PARAM;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pokedox.model.Ability;
import com.example.pokedox.model.PokemonsInfo;
import com.example.pokedox.service.PokemonsRepoService;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class InfoActivity extends AppCompatActivity {
    private TextView textViewHeight;
    private TextView textViewWeight;
    private TextView textViewAbilities;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_layout);
        Button buttonReturn = findViewById(R.id.buttonReturn);
        Intent intent=getIntent();
        String name =intent.getStringExtra(MainActivity.POKEMON_NAME_PARAM);
        TextView textView2 =findViewById(R.id.textView2);
        //ListView listViewInfo =findViewById(R.id.listviewpokemons);
        textView2.setText(name);

        Bundle extras = getIntent().getExtras();
        String imageUrl = extras.getString(POKEMON_IMAGE_PARAM);
        ImageView imageView = findViewById(R.id.imageViewInfo);
        Picasso.get().load(imageUrl).into(imageView);


        textViewAbilities = findViewById(R.id.textView4);
        textViewHeight = findViewById(R.id.textView6);
        textViewWeight = findViewById(R.id.textView8);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://pokeapi.co/api/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        PokemonsRepoService pokemonDetailsService = retrofit.create(PokemonsRepoService.class);
        Call<PokemonsInfo> callPokemonDetails = pokemonDetailsService.searchPokemonDetails(name);

        callPokemonDetails.enqueue(new Callback<PokemonsInfo>() {
            @Override
            public void onResponse(Call<PokemonsInfo> call, Response<PokemonsInfo> response) {
                if (!response.isSuccessful()) {
                    Log.i("info",String.valueOf(response.code()));
                    return;
                }
                PokemonsInfo pokemonDetailsResponse = response.body();
                textViewHeight.setText(" " + pokemonDetailsResponse.height);
                textViewWeight.setText(" " + pokemonDetailsResponse.weight);
                StringBuilder sb = new StringBuilder();
                for (Ability ability : pokemonDetailsResponse.abilities) {
                    sb.append(ability.ability.name).append("\n");
                }
                textViewAbilities.setText(" " + sb.toString());
            }

            @Override
            public void onFailure(Call<PokemonsInfo> call, Throwable t) {
                Log.e("error","Error");
            }
        });

        buttonReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InfoActivity.this, MainActivity.class));
            }
        });

    }
}
