package com.example.pokedox.model;

public class Pokemons {
    public String name;
    //public String url;


}
